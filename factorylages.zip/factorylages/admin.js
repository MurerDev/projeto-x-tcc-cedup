// Painel Admin Factory Açaí - CRUD Simples

const TIPOS = {
  produtos: 'produtos',
  acompanhamentos: 'acompanhamentos',
  pedidos: 'pedidos',
};

const tamanhos = [
  { id: '300ml', nome: 'Mini Fábrica', valor: '300 ml', preco: 16.00 },
  { id: '500ml', nome: 'Alta Produção', valor: '500 ml', preco: 19.00 },
  { id: '700ml', nome: 'Potência Máxima', valor: '700 ml', preco: 25.00 },
];

const acompanhamentos = [
  {
    categoria: 'Frutas',
    itens: [
      { id: 'banana', nome: 'Banana', preco: 3.00, emoji: '🍌' },
      { id: 'morango', nome: 'Morango', preco: 4.00, emoji: '🍓' },
      { id: 'abacaxi', nome: 'Abacaxi', preco: 4.00, emoji: '🍍' },
      { id: 'maracuja', nome: 'Maracujá', preco: 3.50, emoji: '🍇' },
      { id: 'uva-verde', nome: 'Uva verde', preco: 4.00, emoji: '🍇' },
    ],
  },
  {
    categoria: 'Chocolates, doces e complementos',
    itens: [
      { id: 'leite-condensado', nome: 'Leite condensado', preco: 3.50, emoji: '🥛' },
      { id: 'leite-em-po', nome: 'Leite em pó', preco: 3.50, emoji: '🥛' },
      { id: 'bis-branco', nome: 'Bis branco', preco: 3.50, emoji: '🍫' },
      { id: 'bis-preto', nome: 'Bis preto', preco: 3.50, emoji: '🍫' },
      { id: 'pacoquinha', nome: 'Paçoquinha', preco: 3.00, emoji: '🥜' },
      { id: 'amendoim', nome: 'Amendoim granulado', preco: 3.00, emoji: '🥜' },
      { id: 'coco-ralado', nome: 'Coco ralado', preco: 3.00, emoji: '🥥' },
      { id: 'bolacha-oleo', nome: 'Bolacha Óleo', preco: 4.00, emoji: '🍪' },
      { id: 'confete', nome: 'Confete', preco: 3.50, emoji: '🍬' },
      { id: 'ouro-branco', nome: 'Ouro Branco', preco: 4.00, emoji: '🍫' },
      { id: 'sonho-de-valsa', nome: 'Sonho de Valsa', preco: 4.00, emoji: '🍫' },
      { id: 'nutella', nome: 'Nutella', preco: 7.00, emoji: '🍫' },
      { id: 'trento', nome: 'Trento', preco: 4.00, emoji: '🍫' },
      { id: 'kit-kat', nome: 'Kit Kat', preco: 5.00, emoji: '🍫' },
      { id: 'aveia', nome: 'Aveia', preco: 3.00, emoji: '🌾' },
      { id: 'laka', nome: 'Laka', preco: 5.00, emoji: '🍫' },
      { id: 'diamante-negro', nome: 'Diamante Negro', preco: 5.00, emoji: '🍫' },
      { id: 'marshmallow', nome: 'Marshmallow', preco: 4.00, emoji: '🍡' },
      { id: 'ovomaltine', nome: 'Ovomaltine', preco: 4.00, emoji: '🥤' },
      { id: 'creme-avelha', nome: 'Creme de avelã', preco: 4.50, emoji: '🌰' },
      { id: 'chocolate-branco', nome: 'Chocolate branco', preco: 4.50, emoji: '🍫' },
      { id: 'leite-condensado-zero', nome: 'Leite condensado zero lactose', preco: 6.00, emoji: '🥛' },
      { id: 'leite-em-po-zero', nome: 'Leite em pó zero lactose', preco: 6.00, emoji: '🥛' },
      { id: 'mousse-maracuja', nome: 'Mousse de maracujá', preco: 4.00, emoji: '🍮' },
      { id: 'mousse-morango', nome: 'Mousse de morango', preco: 4.00, emoji: '🍮' },
      { id: 'mousse-leite-po', nome: 'Mousse de leite em pó', preco: 4.00, emoji: '🍮' },
      { id: 'calda-chocolate', nome: 'Calda de chocolate', preco: 3.00, emoji: '🍫' },
      { id: 'calda-morango', nome: 'Calda de morango', preco: 3.00, emoji: '🍓' },
    ],
  },
];

let estado = {
  produtos: [],
  acompanhamentos: [],
  pedidos: [],
  viewAtual: 'dashboard',
  itemEditando: null,
  tipoEditando: null,
  tipoParaExcluir: null,
  idParaExcluir: null,
  idParaExcluirPedido: null,
};

function formatarMoeda(valor) {
  return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function mostrarToast(msg) {
  const toast = document.getElementById('toast');
  if (toast) {
    toast.textContent = msg;
    toast.classList.add('mostrar');
    setTimeout(() => toast.classList.remove('mostrar'), 3000);
  }
}

function salvarDados() {
  try {
    localStorage.setItem('factory_produtos', JSON.stringify(estado.produtos));
    localStorage.setItem('factory_acompanhamentos', JSON.stringify(estado.acompanhamentos));
    localStorage.setItem('factory_pedidos', JSON.stringify(estado.pedidos));
  } catch (e) {
    console.error('Erro ao salvar dados:', e);
  }
}

function carregarDados() {
  try {
    const prod = localStorage.getItem('factory_produtos');
    const acc = localStorage.getItem('factory_acompanhamentos');
    const ped = localStorage.getItem('factory_pedidos');

    if (prod) estado.produtos = JSON.parse(prod);
    if (acc) estado.acompanhamentos = JSON.parse(acc);
    if (ped) estado.pedidos = JSON.parse(ped);
  } catch (e) {
    console.error('Erro ao carregar dados:', e);
  }
}

function initAdmin() {
  carregarDados();

  document.querySelectorAll('.nav-item').forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      if (item.id === 'btn-logout') {
        alert('Saindo do painel admin...');
        window.location.href = 'index.html';
        return;
      }
      const view = item.dataset.view;
      if (view) {
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        const viewEl = document.getElementById('view-' + view);
        if (viewEl) viewEl.classList.add('active');
        const pageTitle = document.getElementById('page-title');
        if (pageTitle) pageTitle.textContent = view.charAt(0).toUpperCase() + view.slice(1);
        if (view === 'dashboard') renderDashboard();
        if (view === 'produtos') renderProdutos();
        if (view === 'acompanhamentos') renderAcompanhamentos();
        if (view === 'pedidos') renderPedidos();
        if (view === 'fechamento') renderFechamento();
      }
    });
  });

  const btnNovoProduto = document.getElementById('btn-novo-produto');
  if (btnNovoProduto) btnNovoProduto.addEventListener('click', () => abrirForm(TIPOS.produtos));

  const btnNovoAcompanhamento = document.getElementById('btn-novo-acompanhamento');
  if (btnNovoAcompanhamento) btnNovoAcompanhamento.addEventListener('click', () => abrirForm(TIPOS.acompanhamentos));

  const formItem = document.getElementById('form-item');
  if (formItem) formItem.addEventListener('submit', salvarItem);

  const btnCancelarForm = document.getElementById('btn-cancelar-form');
  if (btnCancelarForm) btnCancelarForm.addEventListener('click', () => fecharModal('modal-form'));

  const btnCancelarExcluir = document.getElementById('btn-cancelar-excluir');
  if (btnCancelarExcluir) btnCancelarExcluir.addEventListener('click', () => fecharModal('modal-excluir'));

  const btnConfirmarExcluir = document.getElementById('btn-confirmar-excluir');
  if (btnConfirmarExcluir) btnConfirmarExcluir.addEventListener('click', confirmarExclusao);
}

function renderDashboard() {
  const elProdutos = document.getElementById('stat-total-produtos');
  const elAcc = document.getElementById('stat-total-acompanhamentos');
  const elPedidos = document.getElementById('stat-total-pedidos');
  const elReceita = document.getElementById('stat-receita');

  if (elProdutos) elProdutos.textContent = estado.produtos.length;
  if (elAcc) elAcc.textContent = estado.acompanhamentos.length;
  if (elPedidos) elPedidos.textContent = estado.pedidos.length;

  const receita = estado.pedidos.reduce((s, p) => s + (p.total || 0), 0);
  if (elReceita) elReceita.textContent = formatarMoeda(receita);
}

function renderProdutos() {
  const tbody = document.getElementById('tbody-produtos');
  if (!tbody) return;
  tbody.innerHTML = '';
  estado.produtos.forEach((p) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>🫐</td>
      <td><strong>${p.nome}</strong></td>
      <td><span class="badge">${p.categoria}</span></td>
      <td>${formatarMoeda(p.preco)}</td>
      <td>${p.descricao || '-'}</td>
      <td>
        <div class="acoes-tabela">
          <button class="btn-editar" onclick="window.app.editar('produtos', ${p.id})">Editar</button>
          <button class="btn-excluir" onclick="window.app.excluir('produtos', ${p.id})">Excluir</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderAcompanhamentos() {
  const tbody = document.getElementById('tbody-acompanhamentos');
  if (!tbody) return;
  tbody.innerHTML = '';
  estado.acompanhamentos.forEach((a) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${a.nome}</strong></td>
      <td><span class="badge">${a.categoria}</span></td>
      <td>${formatarMoeda(a.preco)}</td>
      <td>
        <div class="acoes-tabela">
          <button class="btn-editar" onclick="window.app.editar('acompanhamentos', ${a.id})">Editar</button>
          <button class="btn-excluir" onclick="window.app.excluir('acompanhamentos', ${a.id})">Excluir</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPedidos() {
  const tbody = document.getElementById('tbody-pedidos');
  if (!tbody) return;
  tbody.innerHTML = '';
  
  // Filtrar apenas pedidos que NÃO são "Entregue" para mostrar na lista principal
  const pedidosAtivos = estado.pedidos.filter(p => p.status !== 'Entregue');
  
  if (pedidosAtivos.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:var(--texto-suave); padding:30px;">Nenhum pedido pendente.</td></tr>`;
    return;
  }
  pedidosAtivos.slice().reverse().forEach((p) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>#${p.id}</td>
      <td><strong>${p.nome}</strong></td>
      <td>${p.telefone || '-'}</td>
      <td>${p.endereco}</td>
      <td>${p.pagamento}</td>
      <td>${formatarMoeda(p.total || 0)}</td>
      <td>
        <select class="status-select" data-pedido-id="${p.id}" onchange="window.app.atualizarStatusPedido(${p.id}, this.value)">
          <option value="Pendente" ${p.status === 'Pendente' ? 'selected' : ''}>Pendente</option>
          <option value="Em preparo" ${p.status === 'Em preparo' ? 'selected' : ''}>Em preparo</option>
          <option value="Saiu para entrega" ${p.status === 'Saiu para entrega' ? 'selected' : ''}>Saiu para entrega</option>
          <option value="Entregue" ${p.status === 'Entregue' ? 'selected' : ''}>Entregue</option>
          <option value="Cancelado" ${p.status === 'Cancelado' ? 'selected' : ''}>Cancelado</option>
        </select>
      </td>
      <td>${p.data}</td>
      <td>
        <button class="btn btn-outline btn-detalhes" onclick="window.app.verDetalhesPedido(${p.id})">Ver Detalhes</button>
        <button class="btn btn-outline btn-excluir" onclick="window.app.excluirPedido(${p.id})">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPedidosEntregues() {
  const tbody = document.getElementById('tbody-pedidos-entregues');
  if (!tbody) return;
  tbody.innerHTML = '';
  
  const pedidosEntregues = estado.pedidos.filter(p => p.status === 'Entregue');
  
  if (pedidosEntregues.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--texto-suave); padding:30px;">Nenhum pedido entregue ainda.</td></tr>`;
    return;
  }
  
  pedidosEntregues.slice().reverse().forEach((p) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>#${p.id}</td>
      <td><strong>${p.nome}</strong></td>
      <td>${p.telefone || '-'}</td>
      <td>${p.endereco}</td>
      <td>${p.pagamento}</td>
      <td>${formatarMoeda(p.total || 0)}</td>
      <td>${p.data}</td>
      <td>
        <button class="btn btn-outline btn-detalhes" onclick="window.app.verDetalhesPedido(${p.id})">Ver Detalhes</button>
        <button class="btn btn-outline btn-excluir" onclick="window.app.excluirPedido(${p.id})">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderFechamento() {
  const tbody = document.getElementById('tbody-fechamento');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (estado.pedidos.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--texto-suave); padding:30px;">Nenhum pedido ainda.</td></tr>`;
    return;
  }
  estado.pedidos.slice().reverse().forEach((p) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>#${p.id}</td>
      <td><strong>${p.nome}</strong></td>
      <td>${p.telefone || '-'}</td>
      <td>${p.endereco}</td>
      <td>${p.pagamento}</td>
      <td>${formatarMoeda(p.total || 0)}</td>
      <td><span class="status-badge status-${p.status}">${p.status}</span></td>
      <td>${p.data}</td>
    `;
    tbody.appendChild(tr);
  });

  const totalPedidos = estado.pedidos.length;
  const receitaTotal = estado.pedidos.reduce((s, p) => s + (parseFloat(p.total) || 0), 0);

  document.getElementById('stat-total-pedidos-fechamento').textContent = totalPedidos;
  document.getElementById('stat-receita-total-fechamento').textContent = formatarMoeda(receitaTotal);

  const pedidosPendentes = estado.pedidos.filter(p => p.status === 'Pendente').length;
  const pedidosEntregues = estado.pedidos.filter(p => p.status === 'Entregue').length;
  const medioPorPedido = totalPedidos > 0 ? receitaTotal / totalPedidos : 0;

  document.getElementById('stat-pedidos-pendentes').textContent = pedidosPendentes;
  document.getElementById('stat-pedidos-entregues').textContent = pedidosEntregues;
  document.getElementById('stat-medio-por-pedido').textContent = formatarMoeda(medioPorPedido);

  const pagamentos = {};
  estado.pedidos.forEach(p => {
    if (!pagamentos[p.pagamento]) {
      pagamentos[p.pagamento] = { count: 0, total: 0 };
    }
    pagamentos[p.pagamento].count++;
    pagamentos[p.pagamento].total += parseFloat(p.total) || 0;
  });

  const pagamentosHtml = Object.entries(pagamentos).map(([forma, dados]) => {
    return `
      <div class="resumo-pagamento-item">
        <span>${forma}</span>
        <span>${dados.count} pedidos</span>
        <span>${formatarMoeda(dados.total)}</span>
      </div>
    `;
  }).join('');
  document.getElementById('resumo-pagamento-lista').innerHTML = pagamentosHtml || '<p style="text-align:center; color:#666;">Nenhum pagamento registrado</p>';
}

function abrirForm(tipo) {
  estado.tipoEditando = tipo;
  estado.itemEditando = null;

  const modalTitulo = document.getElementById('modal-titulo');
  const formCategoria = document.getElementById('form-categoria');

  document.getElementById('form-item').reset();
  document.getElementById('form-id').value = '';
  document.getElementById('form-tipo').value = tipo;

  if (tipo === TIPOS.produtos) {
    if (modalTitulo) modalTitulo.textContent = 'Novo Produto';
    if (formCategoria) formCategoria.style.display = 'block';
    if (formCategoria) formCategoria.parentElement.style.display = 'block';
  } else {
    if (modalTitulo) modalTitulo.textContent = 'Novo Acompanhamento';
    if (formCategoria) formCategoria.style.display = 'none';
    if (formCategoria) formCategoria.parentElement.style.display = 'none';
    if (modalTitulo) modalTitulo.textContent = 'Novo Acompanhamento';
  }

  document.getElementById('modal-form').setAttribute('data-aberto', 'true');
  document.body.style.overflow = 'hidden';
}

function editar(tipo, id) {
  const lista = tipo === TIPOS.produtos ? estado.produtos : estado.acompanhamentos;
  const item = lista.find((x) => x.id === id);
  if (!item) return;

  estado.tipoEditando = tipo;
  estado.itemEditando = item;

  document.getElementById('form-id').value = item.id;
  document.getElementById('form-tipo').value = tipo;
  document.getElementById('form-nome').value = item.nome;
  document.getElementById('form-preco').value = item.preco;
  document.getElementById('form-descricao').value = item.descricao || '';
  document.getElementById('form-categoria').value = item.categoria;

  if (tipo === TIPOS.produtos) {
    document.getElementById('modal-titulo').textContent = 'Editar Produto';
    document.getElementById('form-categoria').style.display = 'block';
    document.getElementById('form-categoria').parentElement.style.display = 'block';
  } else {
    document.getElementById('modal-titulo').textContent = 'Editar Acompanhamento';
    document.getElementById('form-categoria').style.display = 'none';
    document.getElementById('form-categoria').parentElement.style.display = 'none';
  }

  document.getElementById('modal-form').setAttribute('data-aberto', 'true');
  document.body.style.overflow = 'hidden';
}

function salvarItem(e) {
  e.preventDefault();

  const id = document.getElementById('form-id').value;
  const tipo = document.getElementById('form-tipo').value;
  const nome = document.getElementById('form-nome').value;
  const preco = parseFloat(document.getElementById('form-preco').value);
  const descricao = document.getElementById('form-descricao').value;
  const categoria = document.getElementById('form-categoria').value;

  const novoItem = {
    id: id ? parseInt(id) : Date.now(),
    nome,
    preco,
    descricao,
    categoria,
  };

  const lista = tipo === TIPOS.produtos ? estado.produtos : estado.acompanhamentos;

  if (id) {
    const idx = lista.findIndex((x) => x.id === novoItem.id);
    if (idx !== -1) lista[idx] = novoItem;
  } else {
    lista.push(novoItem);
  }

  salvarDados();
  fecharModal('modal-form');

  if (tipo === TIPOS.produtos) renderProdutos();
  else renderAcompanhamentos();

  renderDashboard();
  mostrarToast('Item salvo com sucesso!');
}

function excluir(tipo, id) {
  estado.tipoParaExcluir = tipo;
  estado.idParaExcluir = id;

  const lista = tipo === TIPOS.produtos ? estado.produtos : estado.acompanhamentos;
  const item = lista.find((x) => x.id === id);
  document.getElementById('excluir-nome').textContent = item ? item.nome : 'este item';

  document.getElementById('modal-excluir').setAttribute('data-aberto', 'true');
  document.body.style.overflow = 'hidden';
}

function excluirPedido(id) {
  estado.idParaExcluirPedido = id;
  const pedido = estado.pedidos.find(p => p.id === id);
  document.getElementById('excluir-nome').textContent = pedido ? `#${pedido.id} - ${pedido.nome}` : 'este pedido';

  document.getElementById('modal-excluir').setAttribute('data-aberto', 'true');
  document.body.style.overflow = 'hidden';
}

function confirmarExclusao() {
  const tipo = estado.tipoParaExcluir;
  const id = estado.idParaExcluir;
  const idPedido = estado.idParaExcluirPedido;

  if (idPedido) {
    estado.pedidos = estado.pedidos.filter((p) => p.id !== idPedido);
    estado.idParaExcluirPedido = null;
    salvarDados();
    fecharModal('modal-excluir');
    renderPedidos();
    renderDashboard();
    mostrarToast('Pedido excluído com sucesso!');
    return;
  }

  const lista = tipo === TIPOS.produtos ? estado.produtos : estado.acompanhamentos;
  estado[tipo === TIPOS.produtos ? 'produtos' : 'acompanhamentos'] = lista.filter((x) => x.id !== id);

  salvarDados();
  fecharModal('modal-excluir');

  if (tipo === TIPOS.produtos) renderProdutos();
  else renderAcompanhamentos();

  renderDashboard();
  mostrarToast('Item excluído com sucesso!');
}

function fecharModal(id) {
  const el = document.getElementById(id);
  if (el) {
    el.removeAttribute('data-aberto');
    document.body.style.overflow = '';
  }
}

function fecharModalLogin() {
  const modalLogin = document.getElementById('modal-login');
  if (modalLogin) {
    modalLogin.removeAttribute('data-aberto');
    document.body.style.overflow = '';
  }
}

function fecharModalForm() {
  fecharModal('modal-form');
}

function fecharModalExcluir() {
  fecharModal('modal-excluir');
}

async function verDetalhesPedido(id) {
  const pedido = estado.pedidos.find(p => p.id === id);
  if (!pedido) return;

  const itensHtml = pedido.itens.map((item) => {
    const complementosHtml = item.complementos && item.complementos.length
      ? `<div style="font-size:0.85rem; color:#6b5b95; margin-left:10px;">+ ${item.complementos.join(', ')}</div>`
      : '';
    const obsHtml = item.observacao
      ? `<div style="font-size:0.85rem; font-style:italic; color:#d904c8; margin-left:10px;">Obs: ${item.observacao}</div>`
      : '';
    return `
      <div class="detalhe-item" style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #e9cff7;">
        <div>
          <strong>${item.qtd}x ${item.nome}${item.tamanho ? ' · ' + item.tamanho : ''}</strong>
          ${complementosHtml}
          ${obsHtml}
        </div>
        <span style="font-weight:800; color:#5b149a;">${formatarMoeda(item.preco)}</span>
      </div>
    `;
    }).join('');

  document.getElementById('detalhe-numero').textContent = pedido.id;
  document.getElementById('detalhe-cliente').textContent = pedido.nome;
  document.getElementById('detalhe-telefone').textContent = pedido.telefone || '-';
  document.getElementById('detalhe-endereco').textContent = pedido.endereco;
  document.getElementById('detalhe-pagamento').textContent = pedido.pagamento;
  document.getElementById('detalhe-data').textContent = pedido.data;
  document.getElementById('detalhe-total').textContent = formatarMoeda(pedido.total);
  document.getElementById('detalhe-status-select').value = pedido.status;
  document.getElementById('detalhe-itens').innerHTML = itensHtml;

  document.getElementById('modal-pedido-detalhes').setAttribute('data-aberto', 'true');
  document.body.style.overflow = 'hidden';
}

function atualizarStatusPedido(id, novoStatus) {
  const pedido = estado.pedidos.find(p => p.id === id);
  if (pedido) {
    pedido.status = novoStatus;
    salvarDados();
    renderPedidos();
    renderDashboard();
    mostrarToast('Status atualizado: ' + novoStatus);
  }
}

document.querySelectorAll('.modal-overlay').forEach((ov) => {
  ov.addEventListener('click', function() {
    const modal = ov.closest('.modal');
    if (modal) modal.removeAttribute('data-aberto');
  });
});

document.querySelectorAll('.fechar').forEach((btn) => {
  btn.addEventListener('click', () => {
    const modal = btn.closest('.modal');
    if (modal) modal.removeAttribute('data-aberto');
  });
});

const btnSalvarStatus = document.getElementById('btn-salvar-status-detalhe');
if (btnSalvarStatus) {
  btnSalvarStatus.addEventListener('click', () => {
    const id = parseInt(document.getElementById('detalhe-numero').textContent);
    const novoStatus = document.getElementById('detalhe-status-select').value;
    atualizarStatusPedido(id, novoStatus);
    document.getElementById('modal-pedido-detalhes').removeAttribute('data-aberto');
    document.body.style.overflow = '';
  });
}

window.app = {
  mudarView: function(view) {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(i => i.classList.remove('active'));
    const itemAtivo = document.querySelector('.nav-item[data-view="' + view + '"]');
    if (itemAtivo) {
      itemAtivo.classList.add('active');
    }
    const views = document.querySelectorAll('.view');
    views.forEach(v => v.classList.remove('active'));
    const viewEl = document.getElementById('view-' + view);
    if (viewEl) {
      viewEl.classList.add('active');
    }
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = view.charAt(0).toUpperCase() + view.slice(1);
    }
    if (view === 'dashboard') renderDashboard();
    if (view === 'produtos') renderProdutos();
    if (view === 'acompanhamentos') renderAcompanhamentos();
    if (view === 'pedidos') renderPedidos();
    if (view === 'fechamento') {
      renderFechamento();
      renderPedidosEntregues();
    }
  },
  editar: editar,
  excluir: excluir,
  excluirPedido: excluirPedido,
  verDetalhesPedido: verDetalhesPedido,
  atualizarStatusPedido: atualizarStatusPedido,
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAdmin);
} else {
  initAdmin();
}