# Factory Açaí - Delivery Online

Sistema completo de pedidos de açaí com painel administrativo em tempo real usando Supabase.

## 🚀 Deploy no Vercel

### 1. Subir no GitHub
1. Crie um repositório no GitHub (ex: `factory-acai`)
2. Faça upload de todos os arquivos desta pasta:
   - `factorylages/index.html`
   - `factorylages/script.js`
   - `factorylages/style.css`
   - `factorylages/admin.html`
   - `factorylages/admin.js`
   - `factorylages/admin.css`
   - `factorylages/vercel.json`
   - `factorylages/.env.example`
   - `factorylages/README.md`
   - `factorylages/logo.png`
   - `factorylages/cardapio.png`

### 2. Conectar no Vercel
1. Acesse [vercel.com](https://vercel.com)
2. Clique em **"Add New Project"**
3. Selecione seu repositório do GitHub
4. Clique em **"Deploy"**

### 3. Configurar Variáveis de Ambiente
No painel do Vercel, vá em **Settings > Environment Variables** e adicione:

| Nome | Valor |
|------|-------|
| `VITE_SUPABASE_URL` | `https://xkooxzbcrhgygmernqrs.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | `sb_publishable_6ZviyFnLbFDbIYTYzq0RYg_kTBGVxI3` |

### 4. Configurar Banco de Dados no Supabase
No [Supabase](https://supabase.com), vá em **SQL Editor** e execute:

```sql
-- Tabela de pedidos
CREATE TABLE pedidos (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  endereco TEXT,
  telefone TEXT,
  pagamento TEXT,
  total NUMERIC,
  status TEXT DEFAULT 'Pendente',
  data TEXT,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de itens do pedido
CREATE TABLE itens_pedido (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER REFERENCES pedidos(id) ON DELETE CASCADE,
  nome TEXT,
  tamanho TEXT,
  qtd INTEGER DEFAULT 1,
  preco NUMERIC,
  complementos TEXT[],
  observacao TEXT
);

-- Habilitar acesso público para desenvolvimento
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_pedido ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Permitir tudo" ON pedidos FOR ALL USING (true);
CREATE POLICY "Permitir tudo" ON itens_pedido FOR ALL USING (true);
```

---

## 📁 Estrutura do Projeto

```
factorylages/
├── index.html          (Site do cliente)
├── script.js           (Lógica do cliente + Supabase)
├── style.css           (Estilos do cliente)
├── admin.html          (Painel administrativo)
├── admin.js            (Lógica do admin + Supabase)
├── admin.css           (Estilos do admin)
├── logo.png            (Logo da Factory Açaí)
├── cardapio.png        (Imagem do cardápio)
├── vercel.json         (Configuração do Vercel)
├── .env.example        (Exemplo de variáveis de ambiente)
└── README.md           (Este arquivo)
```

---

## 🔐 Senha do Admin

A senha padrão para acessar o painel administrativo é: **factory123**

---

## 📱 Funcionalidades

- ✅ Cardápio com tamanhos e complementos
- ✅ Carrinho de compras
- ✅ Checkout com salvamento no Supabase
- ✅ Painel admin com visualização de pedidos
- ✅ Notificações de novos pedidos em tempo real
- ✅ Consulta de pedido por telefone ou número
- ✅ Responsivo para celular
- ✅ Deploy pronto para Vercel
- ✅ Fechamento de caixa
- ✅ Consultar pedido

---

## 🛠️ Tecnologias

- HTML5, CSS3, JavaScript (Vanilla)
- Supabase (Banco de dados na nuvem)
- Vercel (Hospedagem)

---

## 📞 Como usar

### Cliente:
1. Acesse o site
2. Clique em "🫐 Fazer Pedido"
3. Monte seu açaí (tamanho + complementos)
4. Finalize o pedido no carrinho
5. Preencha dados de entrega
6. Guarde o número do pedido

### Admin:
1. Acesse `admin.html`
2. Digite senha: `factory123`
3. Veja pedidos em tempo real
4. Altere status (Pendente → Em preparo → Saiu para entrega → Entregue)
5. Veja detalhes dos itens de cada pedido

---

## 📞 Suporte

Se precisar de ajuda, entre em contato com o desenvolvedor.